public class Ticket {
    private int ticketID;
    private Booking bookingID;
    private  User userID;
    
        // Constructor
        public Ticket() {
            this.ticketID=ticketID;
            this.bookingID=new Booking();
            this.userID=new User();
    
        }
        // Getters and Setters
        public int getTicketID() {
            return ticketID;
        }
    
        public void setTicketID(int ticketID) {
            this.ticketID = ticketID;
        }
        public Booking getBookingID() {
            return bookingID;
        }
        public void setBookingID(Booking bookingID) {
            this.bookingID = bookingID;
        }
        public User getUserID() {
            return userID;
        }
        public void setUserID(User userID) {
            this.userID = userID;
        }
        
       
    
    }