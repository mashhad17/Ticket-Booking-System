public class Booking {
    private int bookingID;
    private User userID;
    private int numberOfTickets;

    // Constructor
    public Booking() {
        this.bookingID=bookingID;
        this.userID = new User();
        this.numberOfTickets = numberOfTickets;
    }

    // Getters and Setters
    public int getBookingID() {
        return bookingID;
    }

    public void setBookingID(int bookingID) {
        this.bookingID = bookingID;
    }
    public User getUserID() {
        return userID;
    }

    public void setUserID(User userID) {
        this.userID = userID;
    }

    public int getNumberOfTickets() {
        return numberOfTickets;
    }

    public void setNumberOfTickets(int numberOfTickets) {
        this.numberOfTickets = numberOfTickets;
    }


}