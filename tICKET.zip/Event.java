import java.sql.Timestamp;

public class Event {
    private String eventName;
    private Timestamp eventDate;
    private String venue;
    private double price;

    // Constructor
    public Event(String eventName,Timestamp eventDate, String venue, double price) {
        this.eventName=eventName;
        this.eventDate = eventDate;
        this.venue = venue;
        this.price = price;
    }

    // Getters and Setters
    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }
   

    public Timestamp getEventDate() {
        return eventDate;
    }

    public void setEventDate(Timestamp eventDate) {
        this.eventDate = eventDate;
    }

    public String getVenue() {
        return venue;
    }

    public void setVenue(String venue) {
        this.venue = venue;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    
}
